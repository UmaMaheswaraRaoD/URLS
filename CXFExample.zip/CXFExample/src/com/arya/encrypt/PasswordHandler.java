package com.arya.encrypt;

import java.io.IOException;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.UnsupportedCallbackException;

import org.apache.wss4j.common.ext.WSPasswordCallback;

/**
 * 
 *
 */
public class PasswordHandler implements CallbackHandler {

	public void handle(Callback[] callbacks) throws IOException, UnsupportedCallbackException {
		
		WSPasswordCallback pc = (WSPasswordCallback) callbacks[0];
				
		int usage = pc.getUsage();
		
		// Plain-text password
		if (usage == WSPasswordCallback.USERNAME_TOKEN_UNKNOWN) {
			// Simply return here as we let XFire handler perform the authentication 
			// with a data set on the MessageContext by security handler
			// This is done in com.sungard.sws.pi.helperws.ValidateUserTokenHandler
			return;
		}
		
		// Digest / Hashed password
//		if (usage == WSPasswordCallback.USERNAME_TOKEN) {
			// If we were to support digest hashed password, 
			// we would get the plaintext password from the DB and set it and let WSS4J do the validation
//			String plainTextPassword = getPlainTextPasswordFromDB(pc.getIdentifer());
//			pc.setPassword(plainTextPassword);
//		}
	}
}
