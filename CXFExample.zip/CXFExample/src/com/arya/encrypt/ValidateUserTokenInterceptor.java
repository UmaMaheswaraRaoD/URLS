package com.arya.encrypt;

import java.util.Vector;

import org.apache.cxf.binding.soap.SoapMessage;
import org.apache.cxf.binding.soap.interceptor.AbstractSoapInterceptor;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.phase.Phase;
import org.apache.ws.security.WSConstants;
import org.apache.ws.security.WSSecurityEngineResult;
import org.apache.ws.security.WSUsernameTokenPrincipal;
import org.apache.ws.security.handler.WSHandlerConstants;
import org.apache.ws.security.handler.WSHandlerResult;

public class ValidateUserTokenInterceptor extends AbstractSoapInterceptor {

	private static final String CLASS_NAME = "ValidateUserTokenHandler";

	public ValidateUserTokenInterceptor() {
		super(Phase.USER_PROTOCOL);
	}
	
	public void handleMessage(SoapMessage message) throws Fault {
		//String methodName = "handleMessage";
		boolean userTokenValidated = false;
		String password = null;
		Vector result = (Vector) message.getContextualProperty(WSHandlerConstants.RECV_RESULTS);
		for (int i = 0; (result != null) && (i < result.size()); i++) {
			WSHandlerResult res = (WSHandlerResult) result.get(i);
			for (int j = 0; j < res.getResults().size(); j++) {
				WSSecurityEngineResult wsSecurityEngineResult = (WSSecurityEngineResult) res.getResults().get(j);
				
				int action = ((Integer) wsSecurityEngineResult.get(WSSecurityEngineResult.TAG_ACTION)).intValue();
				// If results contain UserNameToken action, then proceed to extract principal
				if ((WSConstants.UT & action) > 0) {
					WSUsernameTokenPrincipal principal = (WSUsernameTokenPrincipal) wsSecurityEngineResult.get(WSSecurityEngineResult.TAG_PRINCIPAL);

					if (principal != null) {
//						if (!principal.isPasswordDigest()
//								|| principal.getNonce() == null
//								|| principal.getPassword() == null
//								|| principal.getCreatedTime() == null) {
//								throw new RuntimeException("Invalid Security Header");
//						} else {
//							userTokenValidated = true;
//						}
					
						
						if(principal.getPassword() != null){
							CryptoLibrary lib = new CryptoLibrary();
							password = lib.decrypt(principal.getPassword());
						}else{
							password = null;
							System.out.println("Login failure - Security processing failed");
						}
						// Authenticate the user against AG
						try {
							
							if(principal.getName().equals("muni") && password.equals("123"))
							userTokenValidated = true;
							//userTokenValidated = workflowEJB.logon(principal.getName(), principal.getPassword());
						} catch (Exception ex) {
							password = null;
							ex.printStackTrace();
						}
					}
				}
			}
		}
		if (!userTokenValidated) {
			System.out.println("not valid user");
		}
	}
}
