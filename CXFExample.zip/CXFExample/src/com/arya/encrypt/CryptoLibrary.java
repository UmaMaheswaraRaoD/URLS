package com.arya.encrypt;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.Provider;
import java.util.Random;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.bouncycastle.util.encoders.Base64;


public class CryptoLibrary {
	private Cipher cipher;
	Random randomNoGen;
	MessageDigest digest;
	SecretKeySpec keySpec;
	IvParameterSpec ivSpec;

	public CryptoLibrary() throws SecurityException {
		String providerClass = "org.bouncycastle.jce.provider.BouncyCastleProvider";
		String keyString = "SunGard Java Team WebDev Pass";
		if(providerClass != null && providerClass.trim().length() > 0){
			try {
				Provider algorithmProvider = (Provider) Class.forName(providerClass).newInstance();
				java.security.Security.addProvider(algorithmProvider);
			} catch (Exception e) {
				throw new SecurityException(
						"FAILED to load encryption algorithm provider class: " + providerClass);
			}
		}
		init(keyString);

	}
	/**
	 * init method which sets the cipher, digest and initialization vector
	 * required for encryption and decryption
	 * @param keyString
	 * @throws SecurityException
	 */
	public void init(String keyString) throws SecurityException {
		 // setup AES cipher in CBC mode with PKCS #5 padding
		try {
			cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
		} catch (NoSuchAlgorithmException noSuchAlgException) {
			throw new SecurityException(
					"No Such Alogrithm Found: " + noSuchAlgException);
		} catch (NoSuchPaddingException noSuchPadException) {
			throw new SecurityException(
					"No Such Padding Found: " + noSuchPadException);
		}

        // setup an IV (initialization vector) that should be
        // randomly generated for each input that's encrypted
        byte[] iv = new byte[cipher.getBlockSize()];
		randomNoGen = SecureRandom.getInstance("SHA256PRNG");
        randomNoGen.nextBytes(iv);
        ivSpec = new IvParameterSpec(iv);

        // hash keyString with SHA-256 and crop the output to 128-bit for key
		try {
			digest = MessageDigest.getInstance("SHA-256");
		} catch (NoSuchAlgorithmException noSuchAlgException) {
			throw new SecurityException(
					"No Such Alogrithm Found: " + noSuchAlgException);
		}
        digest.update(keyString.getBytes());
        byte[] key = new byte[16];
        System.arraycopy(digest.digest(), 0, key, 0, key.length);
        keySpec = new SecretKeySpec(key, "AES");
	}

	/**
	* convenience method for encrypting a string.
	* @param input Description of the Parameter
	* @return String the encrypted string.
	* * @exception SecurityException Description of the Exception
	*/
	public synchronized String encrypt(String input) throws SecurityException {
		try {
			cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec);
			byte[] encrypted = cipher.doFinal(input.getBytes("UTF-8"));
			return new String(Base64.encode(encrypted));
		} catch (Exception e) {
			throw new SecurityException("Could not encrypt: " + e.getMessage());
		}
	}

	/**
	* convenience method for decrypting a string.
	* @param output Description of the Parameter to decrypt
	* @return String the decrypted string.
	* * @exception SecurityException Description of the Exception
	* */
	public synchronized String decrypt(String output) throws SecurityException {
		try {
			cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec);
			byte[] dec =Base64.decode(output.getBytes());
	        byte[] decrypted = cipher.doFinal(dec);
			return new String(decrypted, "UTF-8");
		} catch (Exception e) {
			throw new SecurityException("Could not decrypt: " + e.getMessage());
		}
	}
}
