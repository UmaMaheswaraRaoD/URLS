package com.aranin.weblog4j.services;
 
import java.util.ArrayList;
import java.util.List;

import javax.jws.WebService;

import org.apache.cxf.interceptor.InInterceptors;
 
@WebService(endpointInterface = "com.aranin.weblog4j.services.BookShelfService",name="BookService", targetNamespace = "http://webservice.pi.sws.sungard.com")
@InInterceptors(interceptors={
        "com.arya.encrypt.ValidateUserTokenInterceptor"
})
public class BookShelfServiceImpl implements BookShelfService {

	public String getBook(String name) {
        return "Hello.... "+name;
    }
	
	@Override
	public String getEmailAddressOfPrimaryContact(String userId) throws Exception {
		try {
			ObjectToXMLBuilder otxb = new ObjectToXMLBuilder();
			
			List<OperatorVO> operatorVOs = new ArrayList<OperatorVO>();
			
			OperatorVO operatorVO1 = new OperatorVO();
			operatorVO1.setOperatorId("1");
			operatorVO1.setOperatorName("muni");
			operatorVO1.setEmailAddress("muni@gmail.com");
			
			OperatorVO operatorVO2 = new OperatorVO();
			operatorVO2.setOperatorId("2");
			operatorVO2.setOperatorName("swamy");
			operatorVO2.setEmailAddress("swamy@gmail.com");
			
			operatorVOs.add(operatorVO1);
			operatorVOs.add(operatorVO2);
			
			String tempString= "";
			try {
				tempString = otxb.getEmailAddressOfPrimaryContactXml(operatorVOs);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return tempString;
		} catch (Exception e) {
			e.printStackTrace();
			return "";
		}
	}
}
