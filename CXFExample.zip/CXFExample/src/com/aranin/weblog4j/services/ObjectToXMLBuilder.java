package com.aranin.weblog4j.services;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class ObjectToXMLBuilder {
	
	private Document m_doc;
	private String nsAgHostName = "http://expag";
	final String xsiNS = "http://www.w3.org/2001/XMLSchema-instance";
	private String m_xml = EMPTY;
	final static String EMPTY = "";
	private String hostName = EMPTY;
	final static String ZERO = "0";
	private static boolean needHeader = true;
	private Writer m_out;
	
	final String emailListXsd = "EXPAGWeb/xsd/expag/EmailAddrOfPrimaryContactList.xsd";
	final String emailXsd = "EXPAGWeb/xsd/expag/EmailAddrOfPrimaryContact.xsd";
	final String emailPrefix = "oper";

	public ObjectToXMLBuilder() {
		m_out = new StringWriter();
		try {
			/** Opening a document */
			DocumentBuilderFactory factory = DocumentBuilderFactory
					.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			m_doc = builder.newDocument();

		} catch (ParserConfigurationException pce) {
			pce.printStackTrace();
		}
	}
	
	/**
	 * @param operatorVOs
	 * @return String
	 * @throws IOException
	 * @throws DOMException
	 */
	public String getEmailAddressOfPrimaryContactXml(List<OperatorVO> operatorVOs) throws IOException, DOMException {

		/* Add ROOT Node and namespaces */
		Element root = m_doc.createElement("EmailAddrOfPrimaryContactList");
		m_doc.appendChild(root);
		appendNameSpace(root, "xmlns", getAgSchemaNameSpace(emailListXsd));
		appendNameSpace(root, "xmlns:xsi", xsiNS);
		appendNameSpace(root, "xmlns:" + emailPrefix, getAgSchemaNameSpace(emailXsd));
		appendNameSpace(root, "xsi:schemaLocation", getAgSchemaNameSpace(emailListXsd) + " " + getSchemaURL(emailListXsd));
		String path = getAgSchemaNameSpace(emailXsd);

		if (operatorVOs != null && operatorVOs.size() > 0) {
			
			for (int i = 0; i < operatorVOs.size(); i++) {
				OperatorVO operatorVO = operatorVOs.get(i);
				if (operatorVO != null) {

					Element emailAddrOfPrimaryContact = createNSElement(path, emailPrefix, "EmailAddrOfPrimaryContact");
					root.appendChild(emailAddrOfPrimaryContact);

					Element operatorid = createNSElement(path, emailPrefix, "operatorid");
					Element operatorname = createNSElement(path, emailPrefix, "operatorname");
					Element emailaddress = createNSElement(path, emailPrefix, "emailaddress");

					appendChildValueWithSpace(emailAddrOfPrimaryContact, operatorid, operatorVO.getOperatorId());
					appendChildValueWithSpace(emailAddrOfPrimaryContact, operatorname, operatorVO.getOperatorName());
					appendChildValueWithSpace(emailAddrOfPrimaryContact, emailaddress, operatorVO.getEmailAddress());
				}
			}

		} else {
			root.setAttribute("count", ZERO);
		}
		m_xml = serialize(m_doc);
		return m_xml;
	}
	
	private String getAgSchemaNameSpace(String schemaName) {
		StringBuffer sb = new StringBuffer();
		sb.append(nsAgHostName.trim());
		sb.append("/");
		sb.append(schemaName.trim());
		return sb.toString();
	}
	
	private void appendNameSpace(Element root, String qname, String xsdNamePath) {
		root.setAttribute(qname, xsdNamePath);
	}
	
	/** createNSElement creates Element(node) with namespace and prefixes */
	private Element createNSElement(String nameSpaceURI, String prefix,
			String Qname) throws DOMException {

		Element temp = m_doc.createElementNS(nameSpaceURI, Qname);
		if (prefix != null && prefix.trim().length() > 0) {
			temp.setPrefix(prefix.trim());
		}
		return temp;
	}
	
	private void appendChildValueWithSpace(Element root, Element child,
			String value) {
		value = safeTrim(value);
		appendChildValue(root, child, value);
	}
	
	/** getSchemaURL returns URL location of a schema */
	private String getSchemaURL(String schemaName) {
		StringBuffer sb = new StringBuffer();
		sb.append(hostName.trim());
		sb.append("/");
		sb.append(schemaName.trim());
		return sb.toString();
	}
	
	private static final String safeTrim(String in) {
		if (in == null)
			return " ";
		in = in.trim();
		if (in.length() == 0)
			return " ";
		return in;
	}
	
	private void appendChildValue(Element root, Element child, String value) {

		if (value != null && !value.equals(EMPTY)) {
			root.appendChild(child);
			child.appendChild(m_doc.createTextNode(value));
		}
	}
	
	public String serialize(Document doc) {
		String xml = EMPTY;
		try {
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
	        Transformer transformer = transformerFactory.newTransformer();
	        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
	        if(!needHeader){
	        	transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION,"yes");
	        }
	        StreamResult streamResult = new StreamResult(m_out);
	        DOMSource domSource = new DOMSource(doc.getDocumentElement());
	        transformer.transform(domSource, streamResult);
	        xml = streamResult.getWriter().toString();      
		} catch (Exception e) {
			xml = EMPTY;
		}
		return xml.trim();
	}

}
