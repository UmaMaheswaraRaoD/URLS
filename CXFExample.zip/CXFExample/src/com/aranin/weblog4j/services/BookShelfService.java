package com.aranin.weblog4j.services;
 
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
 
@WebService
public interface BookShelfService {
	@WebMethod(operationName="getBooks")
    public  String getBook(@WebParam(name="userName") String name);
	
	@WebMethod(operationName="getEmailAddressOfPrimaryContacts")
	public String getEmailAddressOfPrimaryContact(@WebParam(name = "userId") String userId) throws Exception;
}